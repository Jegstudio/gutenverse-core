
import { Skeleton } from 'gutenverse-core/components';

const LibrarySkeleton = () => {
    return <div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
        <div style={{ padding: '10px', width: '33.3%', float: 'left', boxSizing: 'border-box' }}>
            <Skeleton variant="rect" height={250} borderRadius={2} />
        </div>
    </div>;
};

export default LibrarySkeleton;